from django.contrib import admin
from django.utils.safestring import mark_safe  # Import manquant
from .models import AccueilImage, Vehicule  # Import combiné

@admin.register(AccueilImage)
class AccueilImageAdmin(admin.ModelAdmin):
    list_display = ('titre', 'image_preview')
    readonly_fields = ('image_preview',)

    def image_preview(self, obj):
        if obj.image:  # Vérification de l'existence de l'image
            return mark_safe(f'<img src="{obj.image.url}" width="200" height="auto">')
        return "Aucune image"

@admin.register(Vehicule)  # Nom du modèle corrigé (Vehicule au lieu de Vehicle)
class VehiculeAdmin(admin.ModelAdmin):
    list_display = ('modele', 'prix', 'image_preview')
    readonly_fields = ('image_preview',)
    search_fields = ('modele',)

    def image_preview(self, obj):
        if obj.image:
            return mark_safe(f'<img src="{obj.image.url}" width="200" height="auto">')
        return "Aucune image"