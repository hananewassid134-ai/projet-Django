from django.db import models

# Create your models here.

class Vehicule(models.Model):
    modele = models.CharField(max_length=100)
    description = models.TextField()
    prix = models.DecimalField(max_digits=10, decimal_places=2)
    moteur = models.CharField(max_length=50)
    puissance = models.CharField(max_length=20)
    autonomie = models.CharField(max_length=20)
    image = models.ImageField(upload_to='vehicules/', blank=True)
    def __str__(self):
        return self.modele


class AccueilImage(models.Model):  # Assurez-vous que l'orthographe est exacte
    titre = models.CharField(max_length=100)
    image = models.ImageField(upload_to='accueil/')
    texte_alternatif = models.CharField(max_length=200)

    def __str__(self):
        return self.titre
