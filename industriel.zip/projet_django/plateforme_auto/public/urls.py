from django.urls import path
from . import views
from django.contrib.auth import views as auth_views


urlpatterns = [
    path('', views.accueil, name='accueil'),
    path('vehicules/', views.vehicules, name='vehicules'),
    path('contact/', views.contact, name='contact'),
    path('contact/success/', views.contact_success, name='contact_success'),
    path('login/', auth_views.LoginView.as_view(template_name='public/login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),


]