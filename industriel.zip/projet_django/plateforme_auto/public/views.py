
from .models import Vehicule
from .models import AccueilImage
from django.shortcuts import render, redirect
from django.core.mail import send_mail
from django.conf import settings
from django.contrib.auth import authenticate, login
from django.contrib.auth.forms import UserCreationForm

# Create your views here.

def accueil(request):
    try:
        image_accueil = AccueilImage.objects.first()  # Première image enregistrée
    except:
        image_accueil = None

    context = {
        'entreprise_nom': "VotreMarqueAuto",
        'entreprise_description': "Leader en fabrication automobile depuis 1985.",
        'image_accueil': image_accueil,  # Passez l'image au template
    }
    return render(request, 'public/accueil.html', context)

def vehicules(request):
    vehicules = Vehicule.objects.all()
    return render(request, 'public/vehicules.html', {'vehicules': vehicules})

def contact(request):
    if request.method == 'POST':
        # Récupération des données du formulaire
        nom = request.POST.get('nom')
        email = request.POST.get('email')
        message = request.POST.get('message')
        # ... autres champs

        # Envoi d'email (exemple)
        send_mail(
            f"Message de {nom}",
            message,
            email,
            [settings.DEFAULT_FROM_EMAIL],
            fail_silently=False,
        )
        return redirect('contact_success')  # Créez cette vue pour un message de succès

    return render(request, 'public/contact.html')

def contact_success(request):
    return render(request, 'public/contact_success.html', {
        'title': 'Message envoyé',
        'message': 'Merci pour votre message. Nous vous contacterons bientôt.'
    })

def login(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('accueil')  # Redirige vers la page d'accueil après inscription
    else:
        form = UserCreationForm()
    return render(request, 'public/register.html', {'form': form})