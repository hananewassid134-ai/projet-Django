from django.shortcuts import render
from django.shortcuts import render, get_object_or_404
from .models import OrdreFabrication, VolumeProduit, LigneProduction
from datetime import date

def production_list(request):
    ordres = OrdreFabrication.objects.all().order_by('-date_debut')
    return render(request, 'industriel/production_list.html', {'ordres': ordres})

def production_detail(request, ordre_id):
    ordre = get_object_or_404(OrdreFabrication, id=ordre_id)
    return render(request, 'industriel/production_detail.html', {'ordre': ordre})

def production_stats(request):
    lignes = LigneProduction.objects.all()
    stats = []

    for ligne in lignes:
        volumes = VolumeProduit.objects.filter(ligne=ligne).order_by('-date')[:7]
        stats.append({'ligne': ligne, 'volumes': volumes})

    return render(request, 'industriel/production_stats.html', {'stats': stats, 'date_auj': date.today()})
# Create your views here.
from django.db.models import Sum, F
from django.utils.timezone import now


def dashboard(request):
    today = date.today()

    # Volumes produits aujourd’hui
    volumes_today = VolumeProduit.objects.filter(date=today)
    total_produit = volumes_today.aggregate(Sum('quantite'))['quantite__sum'] or 0
    total_conforme = volumes_today.aggregate(Sum('conforme'))['conforme__sum'] or 0

    # Taux de conformité (en %)
    taux_conformite = round((total_conforme / total_produit) * 100, 2) if total_produit > 0 else 0

    # Lignes actives / arrêtées
    lignes = LigneProduction.objects.all()
    lignes_actives = lignes.filter(etat='active').count()
    lignes_arret = lignes.filter(etat='arret').count()

    # TRS simplifié = quantité conforme / (quantité prévue théorique)
    # ➕ Tu peux ajouter plus tard le temps prévu de production pour un TRS + précis
    trs = taux_conformite  # Simplification ici

    context = {
        'total_produit': total_produit,
        'taux_conformite': taux_conformite,
        'trs': trs,
        'lignes_actives': lignes_actives,
        'lignes_arret': lignes_arret,
        'date_auj': today,
    }
    return render(request, 'industriel/dashboard.html', context)
from django.utils.timezone import now, timedelta
from django.db.models import Sum
from datetime import date

def dashboard(request):
    today = date.today()
    start_date = today - timedelta(days=6)  # 7 jours = aujourd'hui + 6 jours avant

    # Query : volume produit par jour sur la dernière semaine
    volumes_semaine = (
        VolumeProduit.objects
        .filter(date__range=[start_date, today])
        .values('date')
        .annotate(total_quantite=Sum('quantite'))
        .order_by('date')
    )

    # Préparer les labels (dates) et les données (quantités)
    labels = []
    data = []

    # Construire un dict date -> quantite pour remplir les jours sans données
    quantite_dict = {item['date']: item['total_quantite'] for item in volumes_semaine}

    for i in range(7):
        jour = start_date + timedelta(days=i)
        labels.append(jour.strftime('%d/%m'))
        data.append(quantite_dict.get(jour, 0))  # 0 si pas de production ce jour

    # Le reste des données déjà calculées
    volumes_today = VolumeProduit.objects.filter(date=today)
    total_produit = volumes_today.aggregate(Sum('quantite'))['quantite__sum'] or 0
    total_conforme = volumes_today.aggregate(Sum('conforme'))['conforme__sum'] or 0
    taux_conformite = round((total_conforme / total_produit) * 100, 2) if total_produit > 0 else 0

    lignes = LigneProduction.objects.all()
    lignes_actives = lignes.filter(etat='active').count()
    lignes_arret = lignes.filter(etat='arret').count()

    trs = taux_conformite  # Simplification actuelle

    context = {
        'total_produit': total_produit,
        'taux_conformite': taux_conformite,
        'trs': trs,
        'lignes_actives': lignes_actives,
        'lignes_arret': lignes_arret,
        'date_auj': today,
        'chart_labels': labels,
        'chart_data': data,
    }
    return render(request, 'industriel/dashboard.html', context)


from django.shortcuts import render
from .models import OrdreFabrication, VolumeProduit


def ordres_fabrication_list(request):
    ordres = OrdreFabrication.objects.all()

    for ordre in ordres:
        volumes = VolumeProduit.objects.filter(ordre_fabrication=ordre)
        total_produit = sum(v.quantite for v in volumes)
        ordre.volume_actuel = total_produit
        ordre.avancement = round((total_produit / ordre.volume_prevu) * 100, 1) if ordre.volume_prevu else 0

    return render(request, 'industriel/ordres_list.html', {'ordres': ordres})
from datetime import date
from django.db.models import Sum

def suivi_journalier(request):
    today = date.today()
    volumes = VolumeProduit.objects.filter(date=today)

    total = volumes.aggregate(Sum('quantite'))['quantite__sum'] or 0
    conforme = volumes.aggregate(Sum('conforme'))['conforme__sum'] or 0

    taux_conformite = round((conforme / total) * 100, 2) if total > 0 else 0

    return render(request, 'industriel/suivi_journalier.html', {
        'total': total,
        'conforme': conforme,
        'taux_conformite': taux_conformite,
        'date': today
    })


