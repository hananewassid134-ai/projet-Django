from django.db import models
from django.db import models

class LigneProduction(models.Model):
    nom = models.CharField(max_length=100)
    etat = models.CharField(max_length=50, choices=[
        ('active', 'En service'),
        ('arret', 'À l’arrêt'),
    ])

    def __str__(self):
        return self.nom


class OrdreFabrication(models.Model):
    numero = models.CharField(max_length=100)
    vehicule = models.CharField(max_length=100)
    quantite = models.PositiveIntegerField()
    date_debut = models.DateField()
    date_fin = models.DateField()
    ligne = models.ForeignKey(LigneProduction, on_delete=models.CASCADE)
    etat = models.CharField(max_length=50, choices=[
        ('en_cours', 'En cours'),
        ('termine', 'Terminé'),
        ('suspendu', 'Suspendu'),
    ])

    def __str__(self):
        return f"OF {self.numero} - {self.vehicule}"


class VolumeProduit(models.Model):
    ligne = models.ForeignKey(LigneProduction, on_delete=models.CASCADE)
    date = models.DateField()
    quantite = models.PositiveIntegerField()
    conforme = models.PositiveIntegerField()

    def __str__(self):
        return f"{self.ligne.nom} - {self.date}"


# Create your models here.
