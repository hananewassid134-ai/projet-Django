from django.contrib import admin
from django.contrib import admin
from .models import LigneProduction, OrdreFabrication, VolumeProduit

@admin.register(LigneProduction)
class LigneProductionAdmin(admin.ModelAdmin):
    list_display = ('nom', 'etat')
    search_fields = ('nom',)

@admin.register(OrdreFabrication)
class OrdreFabricationAdmin(admin.ModelAdmin):
    list_display = ('numero', 'vehicule', 'ligne', 'quantite', 'date_debut', 'etat')
    list_filter = ('etat', 'ligne')
    search_fields = ('numero', 'vehicule')

@admin.register(VolumeProduit)
class VolumeProduitAdmin(admin.ModelAdmin):
    list_display = ('ligne', 'date', 'quantite', 'conforme')
    list_filter = ('ligne', 'date')
# Register your models here.
