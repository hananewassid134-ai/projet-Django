from django.urls import path
from . import views

app_name = 'industriel'

urlpatterns = [
    path('production/', views.production_list, name='production_list'),
    path('production/<int:ordre_id>/', views.production_detail, name='production_detail'),
    path('production/stats/', views.production_stats, name='production_stats'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('ordres/', views.ordres_fabrication_list, name='ordres_list'),
    path('suivi-journalier/', views.suivi_journalier, name='suivi_journalier'),
]
